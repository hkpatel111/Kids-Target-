import os
from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'kids_target_secret_key_change_in_production'

DB_NAME = 'kids_target.db'

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    # Kids table
    conn.execute('''CREATE TABLE IF NOT EXISTS kids (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    age INTEGER,
                    avatar TEXT DEFAULT 'boy'
                 )''')
    
    # Tasks table
    conn.execute('''CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    reward REAL NOT NULL,
                    penalty REAL DEFAULT 0,
                    is_active INTEGER DEFAULT 1
                 )''')
    
    # Daily Logs table
    conn.execute('''CREATE TABLE IF NOT EXISTS daily_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kid_id INTEGER,
                    task_id INTEGER,
                    date TEXT NOT NULL,
                    status TEXT DEFAULT 'Pending', -- Pending, Approved, Rejected
                    earned_amount REAL,
                    FOREIGN KEY(kid_id) REFERENCES kids(id),
                    FOREIGN KEY(task_id) REFERENCES tasks(id)
                 )''')
    
    # Payouts table
    conn.execute('''CREATE TABLE IF NOT EXISTS payouts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    kid_id INTEGER,
                    amount REAL,
                    note TEXT,
                    date TEXT,
                    FOREIGN KEY(kid_id) REFERENCES kids(id)
                 )''')
    
    # App Settings (PIN etc)
    conn.execute('''CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                 )''')
    
    # Seed default tasks if empty
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM tasks")
    if cur.fetchone()[0] == 0:
        default_tasks = [
            ("Kachra nikalna (Take out trash)", 2.0, 0),
            ("Subah jaldi uthna (Early wake up)", 5.0, 0),
            ("Homework time par karna (Do homework)", 5.0, 0),
            ("Room clean rakhna (Clean room)", 3.0, 0),
            ("Doodh laana (Bring milk)", 3.0, 0),
            ("Jhoothe bartan rakhna (Keep plates)", 2.0, 0),
            ("Padhai table organize karna", 2.0, 0),
            ("Plant watering (Paudhon ko paani)", 3.0, 0),
            ("Shoes/Slippers jagah par rakhna", 2.0, 0),
            ("Time par sona (Sleep on time)", 3.0, 0),
            ("Bina zidd ke khana khana", 5.0, 0),
            ("Exercise / Yoga / Physical activity", 4.0, 0),
            ("English speaking practice", 4.0, 0),
            ("Chote bhai/behen ki madad karna", 5.0, 0),
            ("Bag packing for school", 3.0, 0)
        ]
        cur.executemany("INSERT INTO tasks (name, reward, penalty) VALUES (?, ?, ?)", default_tasks)
    
    # Default PIN if not set
    cur.execute("SELECT value FROM settings WHERE key='pin'")
    if not cur.fetchone():
        cur.execute("INSERT INTO settings (key, value) VALUES ('pin', '1234')")

    conn.commit()
    conn.close()

with app.app_context():
    init_db()

@app.route('/')
def index():
    conn = get_db_connection()
    kids = conn.execute('SELECT * FROM kids').fetchall()
    
    # Calculate current balance for each kid
    kids_summary = []
    for kid in kids:
        kid_id = kid['id']
        # Approved earnings
        approved = conn.execute('SELECT SUM(earned_amount) FROM daily_logs WHERE kid_id = ? AND status = "Approved"', (kid_id,)).fetchone()[0] or 0.0
        # Payouts deducted
        payouts = conn.execute('SELECT SUM(amount) FROM payouts WHERE kid_id = ?', (kid_id,)).fetchone()[0] or 0.0
        balance = approved - payouts
        
        # Today's status count
        today = datetime.now().strftime('%Y-%m-%d')
        today_tasks = conn.execute('SELECT COUNT(*) FROM daily_logs WHERE kid_id = ? AND date = ? AND status = "Approved"', (kid_id, today)).fetchone()[0]
        
        kids_summary.append({
            'id': kid['id'],
            'name': kid['name'],
            'age': kid['age'],
            'avatar': kid['avatar'],
            'balance': balance,
            'today_tasks': today_tasks
        })
    
    conn.close()
    return render_template('index.html', kids=kids_summary)

@app.route('/profiles', methods=['GET', 'POST'])
def profiles():
    conn = get_db_connection()
    if request.method == 'POST':
        name = request.form['name']
        age = request.form.get('age', 0)
        avatar = request.form.get('avatar', 'boy')
        conn.execute('INSERT INTO kids (name, age, avatar) VALUES (?, ?, ?)', (name, age, avatar))
        conn.commit()
        flash('Kid profile added successfully!', 'success')
        return redirect(url_for('profiles'))
    
    kids = conn.execute('SELECT * FROM kids').fetchall()
    conn.close()
    return render_template('profiles.html', kids=kids)

@app.route('/profiles/delete/<int:kid_id>', methods=['POST'])
def delete_kid(kid_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM kids WHERE id = ?', (kid_id,))
    conn.execute('DELETE FROM daily_logs WHERE kid_id = ?', (kid_id,))
    conn.execute('DELETE FROM payouts WHERE kid_id = ?', (kid_id,))
    conn.commit()
    conn.close()
    flash('Kid profile deleted.', 'info')
    return redirect(url_for('profiles'))

@app.route('/tasks', methods=['GET', 'POST'])
def tasks():
    conn = get_db_connection()
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add':
            name = request.form['name']
            reward = float(request.form['reward'])
            penalty = float(request.form.get('penalty', 0))
            conn.execute('INSERT INTO tasks (name, reward, penalty) VALUES (?, ?, ?)', (name, reward, penalty))
            conn.commit()
            flash('New task added!', 'success')
        elif action == 'edit':
            task_id = request.form['task_id']
            name = request.form['name']
            reward = float(request.form['reward'])
            penalty = float(request.form.get('penalty', 0))
            conn.execute('UPDATE tasks SET name = ?, reward = ?, penalty = ? WHERE id = ?', (name, reward, penalty, task_id))
            conn.commit()
            flash('Task updated successfully!', 'success')
        elif action == 'delete':
            task_id = request.form['task_id']
            conn.execute('DELETE FROM tasks WHERE id = ?', (task_id,))
            conn.commit()
            flash('Task deleted.', 'info')
        return redirect(url_for('tasks'))
    
    tasks_list = conn.execute('SELECT * FROM tasks').fetchall()
    conn.close()
    return render_template('tasks.html', tasks=tasks_list)

@app.route('/daily_log', methods=['GET', 'POST'])
def daily_log():
    conn = get_db_connection()
    kids = conn.execute('SELECT * FROM kids').fetchall()
    tasks_list = conn.execute('SELECT * FROM tasks WHERE is_active = 1').fetchall()
    
    selected_date = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
    selected_kid = request.args.get('kid_id', kids[0]['id'] if kids else 0, type=int)
    
    if request.method == 'POST':
        kid_id = int(request.form['kid_id'])
        date = request.form['date']
        
        # Clear existing logs for this kid and date to re-save
        conn.execute('DELETE FROM daily_logs WHERE kid_id = ? AND date = ?', (kid_id, date))
        
        for task in tasks_list:
            task_id = task['id']
            status_key = f'status_{task_id}'
            status = request.form.get(status_key) # 'Approved' or None
            if status == 'Approved':
                earned = task['reward']
                conn.execute('INSERT INTO daily_logs (kid_id, task_id, date, status, earned_amount) VALUES (?, ?, ?, ?, ?)',
                             (kid_id, task_id, date, 'Approved', earned))
        conn.commit()
        flash('Daily checklist saved successfully!', 'success')
        return redirect(url_for('daily_log', kid_id=kid_id, date=date))
    
    # Fetch existing logs for selected kid & date
    existing_logs = {}
    logs_raw = conn.execute('SELECT * FROM daily_logs WHERE kid_id = ? AND date = ?', (selected_kid, selected_date)).fetchall()
    for l in logs_raw:
        existing_logs[l['task_id']] = l['status']
        
    conn.close()
    return render_template('daily_log.html', kids=kids, tasks=tasks_list, selected_kid=selected_kid, selected_date=selected_date, existing_logs=existing_logs)

@app.route('/reports', methods=['GET', 'POST'])
def reports():
    conn = get_db_connection()
    kids = conn.execute('SELECT * FROM kids').fetchall()
    
    start_date = request.args.get('start_date', '2026-01-01')
    end_date = request.args.get('end_date', datetime.now().strftime('%Y-%m-%d'))
    kid_id = request.args.get('kid_id', 'all')
    
    query = '''SELECT dl.*, k.name as kid_name, t.name as task_name 
               FROM daily_logs dl 
               JOIN kids k ON dl.kid_id = k.id 
               JOIN tasks t ON dl.task_id = t.id 
               WHERE dl.date BETWEEN ? AND ? AND dl.status = "Approved"'''
    params = [start_date, end_date]
    
    if kid_id != 'all':
        query += ' AND dl.kid_id = ?'
        params.append(int(kid_id))
        
    query += ' ORDER BY dl.date DESC'
    logs = conn.execute(query, params).fetchall()
    
    # Summary per kid in this date range
    summary_query = '''SELECT k.name, SUM(dl.earned_amount) as total_earned, COUNT(dl.id) as total_tasks
                       FROM kids k
                       LEFT JOIN daily_logs dl ON k.id = dl.kid_id AND dl.status = "Approved" AND dl.date BETWEEN ? AND ?'''
    summary_params = [start_date, end_date]
    if kid_id != 'all':
        summary_query += ' WHERE k.id = ?'
        summary_params.append(int(kid_id))
    summary_query += ' GROUP BY k.id'
    
    kid_summaries = conn.execute(summary_query, summary_params).fetchall()
    
    conn.close()
    return render_template('reports.html', kids=kids, logs=logs, kid_summaries=kid_summaries, start_date=start_date, end_date=end_date, kid_id=kid_id)

@app.route('/payouts', methods=['GET', 'POST'])
def payouts():
    conn = get_db_connection()
    kids = conn.execute('SELECT * FROM kids').fetchall()
    
    if request.method == 'POST':
        kid_id = int(request.form['kid_id'])
        amount = float(request.form['amount'])
        note = request.form.get('note', 'Pocket Money Redemption')
        date = datetime.now().strftime('%Y-%m-%d')
        
        conn.execute('INSERT INTO payouts (kid_id, amount, note, date) VALUES (?, ?, ?, ?)', (kid_id, amount, note, date))
        conn.commit()
        flash(f'Payout of ₹{amount} recorded successfully!', 'success')
        return redirect(url_for('payouts'))
        
    payout_history = conn.execute('''SELECT p.*, k.name as kid_name FROM payouts p JOIN kids k ON p.kid_id = k.id ORDER BY p.date DESC''').fetchall()
    
    # Calculate balances for payout form dropdown
    kids_data = []
    for kid in kids:
        kid_id = kid['id']
        approved = conn.execute('SELECT SUM(earned_amount) FROM daily_logs WHERE kid_id = ? AND status = "Approved"', (kid_id,)).fetchone()[0] or 0.0
        payouts_total = conn.execute('SELECT SUM(amount) FROM payouts WHERE kid_id = ?', (kid_id,)).fetchone()[0] or 0.0
        bal = approved - payouts_total
        kids_data.append({'id': kid['id'], 'name': kid['name'], 'balance': bal})
        
    conn.close()
    return render_template('payouts.html', kids=kids_data, payout_history=payout_history)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
