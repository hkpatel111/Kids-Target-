# Kids Target App 🎯💰

A complete, feature-rich web application built with Python Flask and SQLite designed to encourage kids with responsibility, daily chores, and financial literacy.

## Features Included:
1. **Kids Profiles Management:** Add multiple kids with names and ages.
2. **Preset & Custom Task Management:** Pre-loaded with 15+ practical daily chores (kachra nikalna, homework, early wakeup, etc.) with custom Add/Edit/Delete options.
3. **Daily Logging Checklist:** Mark daily tasks effortlessly with date selection.
4. **Date-Range Earnings Reports:** Filter and check total earnings from any start date to today.
5. **Wallet & Payouts:** Track savings, pocket money withdrawals, and redemptions.

## How to Run Locally:
1. Install Python (3.8+).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python app.py
   ```
4. Open your browser and go to `http://localhost:5000`.

## GitHub Actions Workflow
The `.github/workflows/deploy.yml` file is included to automatically test and verify code integrity on every push to GitHub.
