# Kids Target

Kids habit, responsibility and earning tracker.

## Included features
- Multiple children
- Target/task list with daily amount
- Daily task submission
- Pending Verification → Parent approval/rejection
- Earnings, savings and spending wallet
- Penalty and bonus transactions
- Date-to-date earning report
- Transaction history
- Streaks and badges
- Parent PIN settings
- Local backup
- Android 10+ / SDK 29 minimum, target SDK 34

## Build
Open the root folder in Android Studio and run `assembleDebug`.
