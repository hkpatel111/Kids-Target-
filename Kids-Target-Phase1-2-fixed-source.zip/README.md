# Kids Target

Kids habit, responsibility and earning tracker.

## Included features
- Multiple children
- Target/task list with daily amount
- Daily task submission
- Pending Verification → Parent approval/rejection
- Earnings, savings and spending wallet
- Penalty and bonus transactions
- Date-to-date earning report
- Transaction history
- Streaks and badges
- Parent PIN settings
- Local backup
- Android 10+ / SDK 29 minimum, target SDK 34

## Build
Open this folder (the folder containing `settings.gradle`) in Android Studio and
run `assembleDebug`.

### GitHub Actions

Upload the **contents of this ZIP** to the repository root. Do not upload the
ZIP file itself as the project source. The included workflow builds the project
from the repository root with Gradle 8.2.1, which matches Android Gradle Plugin
8.2.2.

The debug APK is published by the workflow as the artifact
`Kids-Target-debug-apk`.
