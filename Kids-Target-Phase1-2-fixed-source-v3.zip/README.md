# Kids Target

Kids habit, responsibility and earning tracker.

## Included features
- Multiple children
- Target/task list with daily amount
- Daily task submission
- Pending Verification → Parent approval/rejection
- Earnings, savings and spending wallet
- Penalty and bonus transactions
- Date-to-date earning report
- Transaction history
- Streaks and badges
- Parent PIN settings
- Local backup
- Android 10+ / SDK 29 minimum, target SDK 34

## Build
Open this folder (the folder containing `settings.gradle`) in Android Studio and
run `assembleDebug`.

### GitHub Actions

The included workflow automatically locates the project if `settings.gradle` is
at the repository root or inside a nested folder such as `Kids-Target/`.
It can also unpack a source ZIP found in the repository, but extracting this
ZIP before uploading is still recommended.

The workflow uses Gradle 8.2.1, which matches Android Gradle Plugin 8.2.2.

The debug APK is published by the workflow as the artifact
`Kids-Target-debug-apk`.
